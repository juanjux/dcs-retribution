# Mission-in-Progress Panel — Widget Tree

`MissionProgressPanel(QFrame)` — replaces the central map widget inside the main
vertical splitter. Carries property `style="mission-panel"` (drives the lit
border/glow) and a dynamic property `state` = `"in-progress" | "complete"` so the
QSS can swap the accent and the footer can show the right buttons.

```
MissionProgressPanel(QFrame)                         [style="mission-panel"][state=...]
└─ QVBoxLayout                                       (margins 0, spacing 0)
   │
   ├─ headerBar : QFrame                             [style="mip-header"]
   │  └─ QHBoxLayout
   │     ├─ spinner : QLabel(QMovie loader.gif)      # swapped for checkIcon QLabel when complete
   │     ├─ titleBox : QVBoxLayout (in a QWidget)
   │     │  ├─ title    : QLabel                     [style="mip-title"]   "MISSION IN PROGRESS"
   │     │  └─ subtitle : QLabel                     [style="mip-subtitle"]
   │     ├─ <stretch>
   │     └─ elapsedBox : QVBoxLayout (in a QWidget)
   │        ├─ elapsedCaption : QLabel               [style="mip-caption"] "ELAPSED"
   │        └─ elapsedValue   : QLabel               [style="mip-timer"]   live mm:ss / h:mm:ss
   │
   ├─ statsStrip : QFrame                            [style="mip-stats"]
   │  └─ QHBoxLayout
   │     ├─ realWorldGroup : QWidget                 # caption + start / now stat cells
   │     │  └─ QGridLayout( caption row, then 2 stat cells via _stat_cell() )
   │     ├─ vline1 : QFrame(VLine)
   │     ├─ inGameGroup : QWidget                    # caption "IN-GAME — Turn N" + mission time / sim elapsed
   │     │  └─ QGridLayout
   │     ├─ <stretch>
   │     └─ conditionsRow : QWidget                  # weather chips
   │        └─ QHBoxLayout
   │           ├─ windChip   : QLabel                [style="mip-chip"]  (icon + "240° 12kt")
   │           ├─ cloudChip  : QLabel                [style="mip-chip"]
   │           ├─ tempChip   : QLabel                [style="mip-chip"]
   │           └─ todChip    : QLabel                [style="mip-chip"]  (time-of-day icon + label)
   │
   ├─ mainRow : QWidget                              (stretch = 1)
   │  └─ QHBoxLayout (spacing 0)
   │     │
   │     ├─ leftCol : QWidget                        (stretch ≈ 3)
   │     │  └─ QVBoxLayout
   │     │     ├─ exchangeCard : QFrame              [style="mip-card"]
   │     │     │  └─ QHBoxLayout
   │     │     │     ├─ ratioCaption : QVBoxLayout    "EXCHANGE RATIO" / "enemy : own losses"
   │     │     │     ├─ ratioValue   : QLabel        [style="mip-ratio"]  rich text "2.6 : 1"
   │     │     │     └─ totalsBox    : QHBoxLayout    own / enemy totals (2× _stat_cell)
   │     │     │
   │     │     └─ scoreboard : QFrame                [style="mip-scoreboard"]
   │     │        └─ QVBoxLayout (spacing 0)
   │     │           ├─ scoreHeader : QWidget        # QGridLayout: ""|BLUE·OwnFor|RED·OpFor
   │     │           ├─ scoreGrid   : QGridLayout    # 8 rows, built by _add_score_row()
   │     │           │     each row col0 = iconLabel(QLabel pixmap) + textLabel
   │     │           │              col1 = blueCount QLabel [style="mip-num-blue"]
   │     │           │              col2 = redCount  QLabel [style="mip-num-red"]
   │     │           └─ flightsFooter : QWidget      # airborne / in combat / waiting counters
   │     │              └─ QHBoxLayout (3× _counter_cell)
   │     │
   │     └─ feedCol : QFrame                         [style="mip-feed"]   (fixed width ~360)
   │        └─ QVBoxLayout (spacing 0)
   │           ├─ feedHeader : QWidget               # live dot + "LIVE EVENTS"
   │           └─ feedScroll : QListWidget           [style="mip-feed-list"]
   │                 each row = QListWidgetItem with a setItemWidget(EventRow)
   │                 EventRow(QFrame)[style="mip-event"][side=blue|red|neutral]
   │                   └─ QHBoxLayout: iconLabel | (textLabel / verbLabel VBox) | timeLabel
   │
   └─ footerBar : QFrame                             [style="mip-footer"]
      └─ QHBoxLayout
         IN-PROGRESS state:
            ├─ hintLabel : QLabel "Mission is being played — results poll every ~1s"
            ├─ <stretch>
            ├─ manuallySubmitBtn : QPushButton       [style="btn-primary"]
            └─ abortBtn          : QPushButton       [style="btn-danger"]
         COMPLETE state:
            ├─ acceptBtn         : QPushButton       [style="btn-success"]   (primary, left)
            ├─ <stretch>
            ├─ manuallySubmitBtn : QPushButton       [style="btn-primary"]
            └─ abortBtn          : QPushButton       [style="btn-danger"]
```

## Dim scrim for the surrounding chrome

There is no single "everything else" widget, so dim each surrounding surface with
its own overlay rather than one global one (keeps it inside the existing splitter
layout, no re-parenting):

```
DimScrim(QWidget)                                    [style="dim-scrim"]
  - a frameless translucent overlay (background rgba via QSS)
  - setAttribute(Qt.WA_TransparentForMouseEvents, False)  # eats clicks → non-interactive
  - resized/moved to cover its target via an installed eventFilter on the target
```

Create one `DimScrim` over each of: the top toolbar (`QTopPanel`), the left
mission sidebar, and the bottom info strip. Raise them when the panel is shown,
hide+delete them when it closes. The panel itself is **not** covered, so only it
stays lit and clickable.

## Notes
- Feed uses **QListWidget + setItemWidget**, not QTextBrowser — keeps per-row side
  coloring/icons and lets you `insertItem(0, …)` newest-on-top and cap the length.
- Counters/timer/feed refresh on the existing ~1s `QTimer` and on each debriefing
  poll; only mutate the QLabel text / insert feed rows, never rebuild the tree.
- All icons are existing PNG assets loaded into `QLabel.setPixmap(...)`
  (`resources/ui/...`); no custom-painted widgets, no QCheckBox styling.
