"""
Skeleton layout for the embedded "Mission in Progress" command panel.

Builds the widget tree and applies the property-class styles described in
widget_tree.md / mission_panel.qss. ALL data wiring (timers, debriefing polls,
button handlers) is left as TODO for your side — this file only constructs the
UI and exposes the handles you'll update.

Drop-in replacement for the floating QWaitingForMissionResultWindow(QDialog):
instead of a dialog, this is a QFrame you insert into the central splitter slot
where the live map normally lives, plus DimScrim overlays over the toolbar /
sidebar / info strip so the panel reads as modal.
"""

from __future__ import annotations

from typing import Optional

from PySide6 import QtCore
from PySide6.QtCore import Qt
from PySide6.QtGui import QMovie, QPixmap
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

ICONS = "./resources/ui"

# category -> (label, icon path). Reuse existing PNGs; no custom painting.
SCORE_CATEGORIES = [
    ("aircraft", "Aircraft", f"{ICONS}/misc/medium/plane.png"),
    ("front_line", "Front-line units", f"{ICONS}/units/tank.png"),
    ("convoy", "Convoy units", f"{ICONS}/units/truck.png"),
    ("cargo_ships", "Shipping cargo", f"{ICONS}/units/ship.png"),
    ("airlift_cargo", "Airlift cargo", f"{ICONS}/units/cargo.png"),
    ("ground_objects", "Ground objects", f"{ICONS}/misc/hangar.png"),
    ("scenery", "Scenery", f"{ICONS}/misc/generator.png"),
    ("bases_lost", "Bases", f"{ICONS}/airbase.png"),
]


def _v(*children, spacing=0, margins=(0, 0, 0, 0)) -> QWidget:
    w = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(*margins)
    lay.setSpacing(spacing)
    for c in children:
        (lay.addLayout if isinstance(c, (QHBoxLayout, QVBoxLayout, QGridLayout)) else lay.addWidget)(c)
    return w


def _label(text: str, style: Optional[str] = None) -> QLabel:
    lbl = QLabel(text)
    if style:
        lbl.setProperty("style", style)
    return lbl


# --------------------------------------------------------------------------- #
#  Dim scrim — one per surrounding surface (toolbar / sidebar / info strip)    #
# --------------------------------------------------------------------------- #
class DimScrim(QWidget):
    """Translucent, click-eating overlay that tracks a target widget's geometry."""

    def __init__(self, target: QWidget, parent: QWidget) -> None:
        super().__init__(parent)
        self._target = target
        self.setProperty("style", "dim-scrim")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        # eats mouse events -> surrounding UI is non-interactive while shown
        target.installEventFilter(self)
        self._sync()
        self.raise_()
        self.show()

    def eventFilter(self, obj, event):
        if obj is self._target and event.type() in (
            QtCore.QEvent.Type.Resize,
            QtCore.QEvent.Type.Move,
        ):
            self._sync()
        return False

    def _sync(self) -> None:
        top_left = self._target.mapTo(self.parentWidget(), self._target.rect().topLeft())
        self.setGeometry(top_left.x(), top_left.y(), self._target.width(), self._target.height())
        self.raise_()


# --------------------------------------------------------------------------- #
#  One row in the live events feed                                             #
# --------------------------------------------------------------------------- #
class EventRow(QFrame):
    def __init__(self, icon_path: str, text: str, verb: str, side: str, time_str: str) -> None:
        super().__init__()
        self.setProperty("style", "mip-event")
        self.setProperty("side", side)  # "blue" | "red" | "neutral"

        lay = QHBoxLayout(self)
        lay.setContentsMargins(16, 11, 16, 11)
        lay.setSpacing(11)

        icon = QLabel()
        icon.setPixmap(QPixmap(icon_path).scaledToHeight(18, Qt.TransformationMode.SmoothTransformation))
        icon.setFixedWidth(20)
        lay.addWidget(icon)

        text_lbl = _label(text, "mip-event-text")
        verb_lbl = _label(verb, "mip-event-verb")
        verb_lbl.setProperty("side", side)
        lay.addWidget(_v(text_lbl, verb_lbl), stretch=1)

        lay.addWidget(_label(time_str, "mip-event-time"))


# --------------------------------------------------------------------------- #
#  The panel                                                                   #
# --------------------------------------------------------------------------- #
class MissionProgressPanel(QFrame):
    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setProperty("style", "mission-panel")
        self.setProperty("state", "in-progress")
        self.setMinimumSize(800, 600)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        self._scrims: list[DimScrim] = []

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_header())
        root.addWidget(self._build_stats_strip())
        root.addWidget(self._build_main_row(), stretch=1)
        root.addWidget(self._build_footer())

    # ---- header -------------------------------------------------------- #
    def _build_header(self) -> QFrame:
        bar = QFrame()
        bar.setProperty("style", "mip-header")
        lay = QHBoxLayout(bar)
        lay.setContentsMargins(22, 16, 22, 16)
        lay.setSpacing(18)

        # spinner (in-progress) — replace with a green check QLabel when complete
        self.spinner = QLabel()
        self._spinner_movie = QMovie(f"{ICONS}/loader.gif")
        self.spinner.setMovie(self._spinner_movie)
        self.spinner.setFixedSize(26, 26)
        self._spinner_movie.start()
        lay.addWidget(self.spinner)

        self.title = _label("MISSION IN PROGRESS", "mip-title")
        self.subtitle = _label("Flying turn in DCS — awaiting result", "mip-subtitle")
        lay.addWidget(_v(self.title, self.subtitle))

        lay.addStretch(1)

        self.elapsed_value = _label("00:00", "mip-timer")
        elapsed_box = _v(_label("ELAPSED", "mip-caption"), self.elapsed_value)
        elapsed_box.layout().setAlignment(Qt.AlignmentFlag.AlignRight)
        lay.addWidget(elapsed_box)
        return bar

    # ---- stats strip --------------------------------------------------- #
    def _build_stats_strip(self) -> QFrame:
        strip = QFrame()
        strip.setProperty("style", "mip-stats")
        lay = QHBoxLayout(strip)
        lay.setContentsMargins(22, 14, 22, 14)
        lay.setSpacing(14)

        # real world clocks
        self.rw_start = _label("--:--:--", "mip-stat-value")
        self.rw_now = _label("--:--:--", "mip-stat-value")
        lay.addWidget(self._clock_group("REAL WORLD", [("START", self.rw_start), ("NOW", self.rw_now)]))

        vline = QFrame()
        vline.setFrameShape(QFrame.Shape.VLine)
        lay.addWidget(vline)

        # in-game clocks
        self.ig_time = _label("-- --- --:--", "mip-stat-value")
        self.ig_elapsed = _label("0:00:00", "mip-stat-value")
        self.ingame_group = self._clock_group(
            "IN-GAME — TURN ?", [("MISSION TIME", self.ig_time), ("SIM ELAPSED", self.ig_elapsed)]
        )
        lay.addWidget(self.ingame_group)

        lay.addStretch(1)

        # conditions chips
        chips = QWidget()
        chip_lay = QHBoxLayout(chips)
        chip_lay.setContentsMargins(0, 0, 0, 0)
        chip_lay.setSpacing(8)
        self.wind_chip = _label("240° 12kt", "mip-chip")
        self.cloud_chip = _label("Scattered", "mip-chip")
        self.temp_chip = _label("24°C", "mip-chip")
        self.tod_chip = _label("Day", "mip-chip")  # also setPixmap the time-of-day icon
        for c in (self.wind_chip, self.cloud_chip, self.temp_chip, self.tod_chip):
            chip_lay.addWidget(c)
        lay.addWidget(chips)
        return strip

    def _clock_group(self, caption: str, cells: list[tuple[str, QLabel]]) -> QWidget:
        w = QWidget()
        grid = QGridLayout(w)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(18)
        grid.addWidget(_label(caption, "mip-stat-label"), 0, 0, 1, len(cells))
        for col, (cap, value_lbl) in enumerate(cells):
            grid.addWidget(_label(cap, "mip-stat-label"), 1, col)
            grid.addWidget(value_lbl, 2, col)
        return w

    # ---- main row : scoreboard + feed --------------------------------- #
    def _build_main_row(self) -> QWidget:
        row = QWidget()
        lay = QHBoxLayout(row)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # left column
        left = QWidget()
        left_lay = QVBoxLayout(left)
        left_lay.setContentsMargins(22, 18, 22, 18)
        left_lay.setSpacing(16)
        left_lay.addWidget(self._build_exchange_card())
        left_lay.addWidget(self._build_scoreboard(), stretch=1)
        lay.addWidget(left, stretch=3)

        # right column : feed
        lay.addWidget(self._build_feed())
        return row

    def _build_exchange_card(self) -> QFrame:
        card = QFrame()
        card.setProperty("style", "mip-card")
        lay = QHBoxLayout(card)
        lay.setContentsMargins(20, 14, 20, 14)
        lay.setSpacing(22)

        lay.addWidget(_v(_label("EXCHANGE RATIO", "mip-stat-label"),
                         _label("enemy : own losses", "mip-stat-label")))

        # rich text so the two sides can be colored within one label
        self.ratio_value = _label("", "mip-ratio")
        self.ratio_value.setTextFormat(Qt.TextFormat.RichText)
        self.ratio_value.setText(
            '<span style="color:#D84545">2.6</span>'
            ' <span style="color:#6F7F8B">:</span> '
            '<span style="color:#3592C4">1</span>'
        )
        self.ratio_value.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.ratio_value, stretch=1)

        self.own_total = _label("0", "mip-counter-num")
        self.enemy_total = _label("0", "mip-counter-num")
        totals = QWidget()
        t_lay = QHBoxLayout(totals)
        t_lay.setContentsMargins(0, 0, 0, 0)
        t_lay.setSpacing(22)
        t_lay.addWidget(_v(self.own_total, _label("OWN LOSSES", "mip-counter-label")))
        t_lay.addWidget(_v(self.enemy_total, _label("ENEMY LOSSES", "mip-counter-label")))
        lay.addWidget(totals)
        return card

    def _build_scoreboard(self) -> QFrame:
        board = QFrame()
        board.setProperty("style", "mip-scoreboard")
        lay = QVBoxLayout(board)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # header row
        header = QWidget()
        header.setProperty("style", "mip-score-header")
        h = QGridLayout(header)
        h.setContentsMargins(16, 0, 0, 0)
        h.setColumnStretch(0, 1)
        h.addWidget(_label("CASUALTIES", "mip-stat-label"), 0, 0)
        blue_col = _label("BLUE · OwnFor", "mip-col-blue")
        red_col = _label("RED · OpFor", "mip-col-red")
        blue_col.setAlignment(Qt.AlignmentFlag.AlignCenter)
        red_col.setAlignment(Qt.AlignmentFlag.AlignCenter)
        h.addWidget(blue_col, 0, 1)
        h.addWidget(red_col, 0, 2)
        h.setColumnMinimumWidth(1, 110)
        h.setColumnMinimumWidth(2, 110)
        lay.addWidget(header)

        # rows
        grid_host = QWidget()
        self.score_grid = QGridLayout(grid_host)
        self.score_grid.setContentsMargins(0, 0, 0, 0)
        self.score_grid.setSpacing(0)
        self.score_grid.setColumnStretch(0, 1)
        self.score_grid.setColumnMinimumWidth(1, 110)
        self.score_grid.setColumnMinimumWidth(2, 110)

        self.blue_cells: dict[str, QLabel] = {}
        self.red_cells: dict[str, QLabel] = {}
        for r, (key, label, icon_path) in enumerate(SCORE_CATEGORIES):
            self._add_score_row(r, key, label, icon_path)
            self.score_grid.setRowStretch(r, 1)
        lay.addWidget(grid_host, stretch=1)

        lay.addWidget(self._build_flights_footer())
        return board

    def _add_score_row(self, r: int, key: str, label: str, icon_path: str) -> None:
        cell = QWidget()
        cl = QHBoxLayout(cell)
        cl.setContentsMargins(16, 0, 16, 0)
        cl.setSpacing(12)
        icon = QLabel()
        icon.setPixmap(QPixmap(icon_path).scaledToHeight(18, Qt.TransformationMode.SmoothTransformation))
        icon.setFixedWidth(22)
        cl.addWidget(icon)
        cl.addWidget(_label(label, "mip-row-label"))
        cl.addStretch(1)
        self.score_grid.addWidget(cell, r, 0)

        blue = _label("0", "mip-num-blue")
        red = _label("0", "mip-num-red")
        blue.setAlignment(Qt.AlignmentFlag.AlignCenter)
        red.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.score_grid.addWidget(blue, r, 1)
        self.score_grid.addWidget(red, r, 2)
        self.blue_cells[key] = blue
        self.red_cells[key] = red

    def _build_flights_footer(self) -> QWidget:
        foot = QWidget()
        foot.setProperty("style", "mip-flights")
        lay = QHBoxLayout(foot)
        lay.setContentsMargins(16, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(_label("FLIGHTS", "mip-stat-label"))

        self.cnt_airborne = _label("0", "mip-counter-num")
        self.cnt_combat = _label("0", "mip-counter-num")
        self.cnt_waiting = _label("0", "mip-counter-num")
        for num, cap in [
            (self.cnt_airborne, "airborne"),
            (self.cnt_combat, "in combat"),
            (self.cnt_waiting, "waiting"),
        ]:
            cell = QWidget()
            c = QHBoxLayout(cell)
            c.setContentsMargins(0, 8, 0, 8)
            c.setSpacing(6)
            c.addStretch(1)
            c.addWidget(num)
            c.addWidget(_label(cap, "mip-counter-label"))
            c.addStretch(1)
            lay.addWidget(cell, stretch=1)
        return foot

    # ---- feed ---------------------------------------------------------- #
    def _build_feed(self) -> QFrame:
        feed = QFrame()
        feed.setProperty("style", "mip-feed")
        feed.setFixedWidth(360)
        lay = QVBoxLayout(feed)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        header = QWidget()
        header.setProperty("style", "mip-feed-header")
        h = QHBoxLayout(header)
        h.setContentsMargins(18, 14, 18, 14)
        h.setSpacing(9)
        self.feed_dot = QLabel("●")  # pulse via a QTimer toggling visibility; not custom-painted
        self.feed_dot.setStyleSheet("color:#82A466; font-size:10px;")
        h.addWidget(self.feed_dot)
        h.addWidget(_label("LIVE EVENTS", "mip-stat-label"))
        h.addStretch(1)
        lay.addWidget(header)

        self.feed_list = QListWidget()
        self.feed_list.setProperty("style", "mip-feed-list")
        self.feed_list.setSelectionMode(QListWidget.SelectionMode.NoSelection)
        self.feed_list.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        lay.addWidget(self.feed_list, stretch=1)
        return feed

    def prepend_event(self, icon_path: str, text: str, verb: str, side: str, time_str: str) -> None:
        """Newest on top. Call from the debriefing-diff handler."""
        item = QListWidgetItem(self.feed_list)
        row = EventRow(icon_path, text, verb, side, time_str)
        item.setSizeHint(row.sizeHint())
        self.feed_list.insertItem(0, item)
        self.feed_list.setItemWidget(item, row)
        while self.feed_list.count() > 200:  # cap length for performance
            self.feed_list.takeItem(self.feed_list.count() - 1)

    # ---- footer -------------------------------------------------------- #
    def _build_footer(self) -> QFrame:
        bar = QFrame()
        bar.setProperty("style", "mip-footer")
        self._footer_lay = QHBoxLayout(bar)
        self._footer_lay.setContentsMargins(22, 14, 22, 14)
        self._footer_lay.setSpacing(12)

        self.hint = _label("Mission is being played — results poll every ~1s", "mip-footer-hint")
        self.accept_btn = QPushButton("Accept results")
        self.accept_btn.setProperty("style", "btn-success")
        self.manually_submit_btn = QPushButton("Manually Submit  [Advanced]")
        self.manually_submit_btn.setProperty("style", "btn-primary")
        self.abort_btn = QPushButton("Abort mission")
        self.abort_btn.setProperty("style", "btn-danger")

        self._layout_footer(complete=False)
        return bar

    def _layout_footer(self, complete: bool) -> None:
        # clear
        while self._footer_lay.count():
            it = self._footer_lay.takeAt(0)
            if it.widget():
                it.widget().setParent(None)

        if complete:
            self._footer_lay.addWidget(self.accept_btn)
            self._footer_lay.addStretch(1)
            self._footer_lay.addWidget(self.manually_submit_btn)
            self._footer_lay.addWidget(self.abort_btn)
        else:
            self._footer_lay.addWidget(self.hint)
            self._footer_lay.addStretch(1)
            self._footer_lay.addWidget(self.manually_submit_btn)
            self._footer_lay.addWidget(self.abort_btn)
        self.accept_btn.setVisible(complete)
        self.hint.setVisible(not complete)

    # ---- state switch -------------------------------------------------- #
    def set_complete(self, complete: bool) -> None:
        self.setProperty("state", "complete" if complete else "in-progress")
        self.style().unpolish(self)
        self.style().polish(self)  # re-evaluate property-based QSS

        if complete:
            self._spinner_movie.stop()
            self.spinner.setMovie(None)
            self.spinner.setPixmap(
                QPixmap(f"{ICONS}/misc/proceed.png").scaledToHeight(26, Qt.TransformationMode.SmoothTransformation)
            )
            self.title.setText("MISSION COMPLETE")
            self.subtitle.setText("Results ready — review & accept to process the turn")
            self.prepend_divider("—— MISSION ENDED ——")
        self._layout_footer(complete=complete)

    def prepend_divider(self, text: str) -> None:
        item = QListWidgetItem(self.feed_list)
        lbl = _label(text, "mip-feed-divider")
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        item.setSizeHint(lbl.sizeHint())
        self.feed_list.insertItem(0, item)
        self.feed_list.setItemWidget(item, lbl)

    # ---- scrim management --------------------------------------------- #
    def install_scrims(self, surfaces: list[QWidget], overlay_parent: QWidget) -> None:
        """surfaces = [top_toolbar, mission_sidebar, info_strip]."""
        for s in surfaces:
            self._scrims.append(DimScrim(s, overlay_parent))

    def remove_scrims(self) -> None:
        for s in self._scrims:
            s.hide()
            s.deleteLater()
        self._scrims.clear()
